Website made for company Biuro Handlowe Regpol in React (Gatsby).
I made a product catalog (width filtering and search bar) width headless CMS to store info about products, then fetched it through GraphQL,
for image optimization i used gatsby image plugin.
